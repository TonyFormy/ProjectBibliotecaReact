import React, { useState, useEffect } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
//import { Button } from 'primereact/button';
function ProductTable(props) {

  // ===========================================================================
  // STATI DEI COMPONENTI ...
  // ===========================================================================


  const [risultato, setRisultato] = useState('');
  const [selectedProduct, setSelectedProduct] = useState('');


  //////////////////////////////////////////////////////////
  ///////// USEEFFECT E FUNZIONE PER RENDERIZZAZIONE 
  //////////////////////////////////////////////////////////
  useEffect(() => {
    VisualizzaDati();

    // eslint-disable-next-line 
  }, [props.datiQuery, props.numeroProd]);


  props.riceviSelection(selectedProduct);

  function VisualizzaDati() {

    fetch(`http://212.77.91.19:8081/BibliotecaOnlineWS/v1/engine/articles?token=tk_corso&art_per_pagina=${props.numeroProd}&q=${props.datiQuery}`)
      .then(response => response.json())
      .then(data => {
        setRisultato(data.articoli);

      })
      //console.log(data))
      .catch(err => console.error(err));

    setSelectedProduct('');
  }

  //////////////////////////////////////////////////
  /////////// FUNZIONE PER FORMATTARE PREZZO 
  /////////////////////////////////////////////////////////
  const formatCurrency = (value) => {
    return value.toLocaleString('it-IT', { style: 'currency', currency: 'EUR' });
  };

  const priceBodyTemplate = (product) => {
    return formatCurrency(product.prezzoAlPubblico);
  };


  ////////////////////////////////////////////////////
  ///////// FUNZIONE PER ESTRAPOLARE IMMAGINI 
  /////////////////////////////////////////////////////
  function imageBodyTemplate(rowData) {
    let img;
    if (rowData.allegati.length !== '') {
      rowData.allegati.forEach(element => {

        if (element.tipo.includes('IMMAGINE')) {
          img = element.url;
        }
      });
      return <img style={{ width: '4rem' }} src={img} onError={(e) => e.target.src = 'https://www.primefaces.org/wp-content/uploads/2020/05/placeholder.png'} alt={''} />;
    }

  }



  console.log(risultato);




  ////////////////////////////////////////////////////////////
  ////// RETURN CONDIZIONATO 
  ///////////////////////////////////////////////////////////

  if (props.datiQuery !== '') {
    return (

      <div>
        <DataTable value={risultato}
          selectionMode="single"  selection={selectedProduct} 
          columnResizeMode="expand" scrollable scrollHeight="600px" virtualScrollerOptions={{ itemSize: 80 }} 
          resizableColumns tableStyle={{ minWidth: '105rem' }}
          onSelectionChange={(e) => setSelectedProduct(e.value)} >
          <Column style={{ fontSize: '15px'}} field="id" header="Id"></Column>
          <Column style={{ fontSize: '15px' }} body={imageBodyTemplate} header="Immagine"></Column>
          <Column style={{ fontSize: '15px' }} field="siglaAzienda" header="Sigla Azienda"></Column>
          <Column style={{ fontSize: '15px' }} field="nomeAzienda" header="Nome Azienda"></Column>
          <Column style={{ fontSize: '15px' }} field="marchio" header="Marchio"></Column>
          <Column style={{ fontSize: '15px' }} field="codiceProdotto" header="Codice Prodotto"></Column>
          <Column style={{ fontSize: '15px' }} field="codiceEAN" header="Codice EAN"></Column>
          <Column style={{ fontSize: '15px' }} field="descrizioneProdotto" header="Descrizione Prodotto"></Column>
          <Column style={{ fontSize: '15px' }} field="prezzoAlPubblico" header="Prezzo Al Pubblico" body={priceBodyTemplate}></Column>
          <Column style={{ fontSize: '15px' }} field="famigliaStatistica" header="Famiglia Statistica"></Column>
          <Column style={{ fontSize: '15px' }} field="descFamStatistica" header="Desc. Fam. Statistica"></Column>
          <Column style={{ fontSize: '15px' }} field="disponibile" header="Disponibile"></Column>
          <Column style={{ fontSize: '15px' }} field="inPromozione" header="Promozione"></Column>
        </DataTable>
      </div>


    );
  }
}

export default ProductTable;