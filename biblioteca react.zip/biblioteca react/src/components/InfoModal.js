import React, { useState, useEffect } from 'react';
import { DataTable } from 'primereact/datatable';
import { Column } from 'primereact/column';
import { Dialog } from 'primereact/dialog';
import { Button } from 'primereact/button';
import 'primereact/resources/primereact.css';
//import { InputText } from 'primereact/inputtext';


function InfoModal(props) {

  // ===========================================================================
  // STATI DEI COMPONENTI ...
  // ==========================================================================


  const [visible, setVisible] = useState('');
  const [allegati, setAllegati] = useState('');
  const [barcode, setBarcode] = useState('');

  /////////////////////////////////////////////////////////////
  ///////// USEEFFECT SET VISIBILITA DIALOG, stato Allegati e stato Barcode
  ////////////////////////////////////////////////////////////

  useEffect(() => {
    setVisible(true);
    console.log(props.selectionModal);
    setAllegati(...props.selectionModal.allegati);
    setBarcode(...[props.selectionModal.elencoBarcode]);
  }, [props.selectionModal]);


  console.log(allegati);
  console.log(barcode);




  /////////////////////////////////////////////////////////////////////////////////////
  //////// FUNZIONE PER RENDERIZZARE IMMAGINE RACCHIUSA IN ALLEGATI
  /////////////////////////////////////////////////////////////////////////////
  function imageBodyTemplate() {
    let img;
    if (props.selectionModal.allegati.length !== 0) {
      props.selectionModal.allegati.forEach(element => {
        if (element.tipo.includes('IMMAGINE'))
          img = element.url;
      });
      return <center><img style={{ width: '10rem' }} src={img} onError={(e) => e.target.src = 'https://www.primefaces.org/wp-content/uploads/2020/05/placeholder.png'} alt={''} /></center>;
    }
    else {
      <tr> no allegati </tr>
    }
  }
  ////////////////////////////////////////////////////////////////////////////////
  ///////////////// FUNZIONE PER MOSTRARE LINK ALLEGATI
  ////////////////////////////////////////////////////////////////////////////////////

  function Links() {
    let link;
    if (props.selectionModal.allegati.length !== 0) {
      props.selectionModal.allegati.forEach(element => {
        if (element.tipo.includes('SCHEDA'))
          link = element.url;
      });
      return <center><Button><a style={{ fontSize: '15px', color: 'white', textDecoration: 'none' }} href={link} target='_blank' rel="noreferrer">Visualizza Allegato</a></Button></center>

        ;
    }
    else {
      <tr> no allegati </tr>
    }
  }


  ///////////////////////////////////////////////
  //////// RETURN
  /////////////////////////////////////////////
  return (
    <div >
  
      <Dialog header="Scheda prodotto" visible={visible} maximizable style={{ width: '50vw', height: '30vw' }} onHide={() => setVisible(false)}>
        <div >
          <div>{imageBodyTemplate()}</div>
          <br/><br/>
          <div >
            <DataTable value={barcode} 
            scrollable scrollHeight="600px" 
          resizableColumns tableStyle={{ minWidth: '10rem'}}>
              <Column style={{ fontSize: '15px' }} field="codiceProdotto" header="Codice Prodotto"></Column>
              <Column style={{ fontSize: '15px' }} field="codiceBarcodeConfezione" header="Codice Barcode Confezione"></Column>
              <Column style={{ fontSize: '15px' }} field="codiceEAN" header="Codice EAN"></Column>
              <Column style={{ fontSize: '15px' }} field="codiceIntrastat" header="Codice Intrastat"></Column>
              <Column style={{ fontSize: '15px' }} field="dataIntroduzione" header="Data Introduzione"></Column>
              <Column style={{ fontSize: '15px' }} field="dataUltimaVariazioneImmissione" header="Data Ultima Variazione Immissione"></Column>
              <Column style={{ fontSize: '15px' }} field="dimensioneAltezza" header="Dimensione Altezza"></Column>
              <Column style={{ fontSize: '15px' }} field="dimensioneMassimaBaseDiametro" header="Dimensione Massima Base Diametro"></Column>
              <Column style={{ fontSize: '15px' }} field="dimensioneMinimaBase" header="Dimensione Minima Base"></Column>
              <Column style={{ fontSize: '15px' }} field="occorrenzaRame" header="Occorrenza Rame"></Column>
              <Column style={{ fontSize: '15px' }} field="pesoNettoAlMetroChilogrammo" header="Peso Netto Al Metro Chilogrammo"></Column>
              <Column style={{ fontSize: '15px' }} field="pesoLordo" header="Peso Lordo"></Column>
              <Column style={{ fontSize: '15px' }} field="qualificatoreBarcode" header="Qualificatore Barcode"></Column>
              <Column style={{ fontSize: '15px' }} field="quantitaConfezione" header="Quantita Confezione"></Column>
              <Column style={{ fontSize: '15px' }} field="reciproco" header="Reciproco"></Column>
              <Column style={{ fontSize: '15px' }} field="ribaltabile" header="Ribaltabile"></Column>
              <Column style={{ fontSize: '15px' }} field="tipoDiImballo" header="Tipo Di Imballo"></Column>
              <Column style={{ fontSize: '15px' }} field="unitaDiMisura" header="Unità Di Misura"></Column>
              <Column style={{ fontSize: '15px' }} field="unitaMisuraPesi" header="Unità Misura Pesi"></Column>
            </DataTable>
          </div>
          <br/><br/>
          {Links()}
        </div>
      </Dialog>
    </div>
  );
}



export default InfoModal;