import React, { useState } from 'react';
import { InputText } from "primereact/inputtext";
import { Button } from 'primereact/button';
import { Dropdown } from 'primereact/dropdown';
import 'primeflex/primeflex.css';
function SearchBar(props) {


   // ===========================================================================
// STATI DEI COMPONENTI ...
// ===========================================================================

    const [testo, setTesto] = useState('interr');
const [selectNumber,setSelectNumber] = useState(10);


/////////////////////////////////////////////////////////////
////////// FUNZIONE RANGE
////////////////////////////////////////////////////////////////
const range = ( low, high, step ) => {
  
    let matrix = [];
    let inival, endval, plus;
    let walker = step || 1;
    let chars = false;
  
    if ( !isNaN( low ) && !isNaN( high ) ) {
      inival = low;
      endval = high;
    } else if ( isNaN( low ) && isNaN( high ) ) {
      chars = true;
      inival = low.charCodeAt( 0 );
      endval = high.charCodeAt( 0 );
    } else {
      inival = ( isNaN( low ) ? 0 : low );
      endval = ( isNaN( high ) ? 0 : high );
    }
  
    plus = ( ( inival > endval ) ? false : true );
    if ( plus ) {
      while ( inival <= endval ) {
        matrix.push( ( ( chars ) ? String.fromCharCode( inival ) : inival ) );
        inival += walker;
      }
    } else {
      while ( inival >= endval ) {
        matrix.push( ( ( chars ) ? String.fromCharCode( inival ) : inival ) );
        inival -= walker;
      }
    }
  
    return matrix;
  }


///////////////////////////////////////////////////
////////// FUNZIONE INVIO PARAMETRI DI RICERCA
/////////////////////////////////////////////////////////////

   const InviaRicerca = (e)=>{
     props.inviaRicerca(testo,selectNumber);
    }

    let Numbers = range(10,50);


//////////////////////////////////////////////////
/////////////// RETURN
//////////////////////////////////////////////////


    return (
        <div>
            <h4>&nbsp; &nbsp; &nbsp;&nbsp;&nbsp;Descrizione Prod. &nbsp; &nbsp; &nbsp;&nbsp; &nbsp; &nbsp; &nbsp;Num. prod.</h4>
            <InputText  header='Cerca' value={testo}  placeholder='Cerca Elemento' onChange={(e) => setTesto(e.target.value)}/>&nbsp;
            <Dropdown value={selectNumber} onChange={(e) => setSelectNumber(e.value)} options={Numbers} 
                 className="w-full md:w-6rem" />&nbsp;
                <Button label="cerca" type='submit' severity="success" raised onClick={(e) =>InviaRicerca() } />
            <br></br><br></br>
        </div>
    );

}

export default SearchBar;