import React, { useState } from 'react';
import './App.css';
import ProductTable from "./components/ProductTable";
import SearchBar from "./components/SearchBar";
import InfoModal from "./components/InfoModal";

function App() {


  // ===========================================================================
// STATI DEI COMPONENTI ...
// ===========================================================================

const [datiQuery,setDatiQuery] = useState('');
const [numeroProd,setnumeroProd] = useState('');
const [selectionModal,setSelectionModal] = useState('');


//////////////////////////////////////////////////////////////////
////////////// funzioni per settaggio paramentri
///////////////////////////////////////////////////////////////////
function riceviRicerca(text,number){
  setDatiQuery(text);
  setnumeroProd(number);
}

function riceviSelection(select){
  setSelectionModal(select)
}

console.log(datiQuery,numeroProd)


function renderModal(){
  if(selectionModal!=='')
  return<>
  
   <InfoModal selectionModal={selectionModal}/>
  </>
}
///////////////////////////////////////////////
//////
////////////////////////////////////////////////
  return (
    <div>
      <center>
      <img style={{ width: '300px',position:'fixed',bottom:'730px',right:'850px' }} src="logo.png" alt=''/>
        </center>
      <SearchBar inviaRicerca={riceviRicerca}/>
      <center>
      <ProductTable datiQuery={datiQuery} numeroProd={numeroProd}  riceviSelection={riceviSelection}/>
      {renderModal()}
      </center>
    </div>
  );
}

export default App;
